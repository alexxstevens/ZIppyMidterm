<?php
    function get_classes() {
        global $db;
        $query = 'SELECT * FROM classes ORDER BY code';
        $statement = $db->prepare($query);
        $statement->execute();
        $classes = $statement->fetchAll();
        $statement->closeCursor();
        return $classes;
    }
    
    function get_class_name($class_code) {
      global $db;
      $query = 'SELECT * FROM classes WHERE code = :class_code';
      $statement = $db->prepare($query);
      $statement->bindValue(':class_code', $class_code);
      $statement->execute();
      $class = $statement->fetch();
      $statement->closeCursor();
      $class_name = $class['class'];
      return $class_name;
    }
?>

