<?php
    function get_types() {
        global $db;
        $query = 'SELECT * FROM types ORDER BY code';
        $statement = $db->prepare($query);
        $statement->execute();
        $types = $statement->fetchAll();
        $statement->closeCursor();
        return $types;
    }
    
    function get_type_name($type_code) {
      global $db;
      $query = 'SELECT * FROM types WHERE code = :type_code';
      $statement = $db->prepare($query);
      $statement->bindValue(':type_code', $type_code);
      $statement->execute();
      $type = $statement->fetch();
      $statement->closeCursor();
      $type_name = $type['type'];
      return $type_name;
    }
?>


<h1><?php print_r($types); ?></h1>
<h1>test list</h1>
<?php foreach ($types as $type) : ?>
        <ul>
          <li><?php echo $type['type']; ?></li>
       </ul>
<?php endforeach; ?>    