<?php
$dsn = 'mysql:host=localhost;dbname=zippyusedautos';
$username = 'root';
$password = 'MesA683103!';

// Create connection
 try {
        $db = new PDO($dsn, $username, $password);
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        include('../errors/database_error.php');
        exit();
    }



$sql = 'SELECT product_id, make, model, type_code, price FROM vehicles';
$result = $db->query($sql);

if ($result != NULL) {
    // output data of each row
    while($row = $result->fetch()) {
        echo "Product_ID - " . $row["product_id"]. 
             "; Make - " . $row["make"]. 
             "; Model - " . $row["model"]. 
             "; Type_Code - " . $row["type_code"].
             "; Price - " . $row["price"]. 
             "<br>" ;
    }
} else {
    echo "0 results";
}

?>