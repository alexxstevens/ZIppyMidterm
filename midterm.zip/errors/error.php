<?php include '../view/header.php'; ?>
    
    <main>
        <h2 class="top">Error</h2>
        <p><?php echo $error; ?></p>
    </main>
<?php include '../view/footer.php'; ?>