<?php include '../view/header.php'; ?>

    <main>
        <h1>Database Error</h1>
        <p>There was an error connecting to the database. Please try again later and contact administrator if error persists.</p>
        <p>Error message: <?php echo $error_message; ?></p>
        <p>&nbsp;</p>
    </main>


<?php include '../view/footer.php'; ?>