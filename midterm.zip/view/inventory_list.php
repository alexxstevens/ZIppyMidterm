<?php include 'header.php'; ?>
<br>
<section id="dropdowns">
  <div class="dropdown" id="type">
  
    <form action="." method="get" id="type_selection">
    <button class="btn btn-secondary dropdown-toggle btn-lg btn-block" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      Select a Type to View
    </button>
    <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
     <?php foreach ($types as $type) : ?>
      <button class="dropdown-item"  type="button"value="<?php echo $type ['code']; ?>">
          <?php echo $type['type']; ?>
      </button>
     <?php endforeach; ?>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" type="button" value="0">View All Types
      </button>
    </div>
  </div>

    <input class="btn btn-primary" type="submit" value="Submit">
     </form>

<br>
  
<h1>
  <?php echo $types?>
     </h1>
</section>






<br>
<?php include 'footer.php'; ?>