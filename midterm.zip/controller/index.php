<?php
    require('../model/database.php');
    require('../model/types_db.php');
    require('../model/vehicles_db.php');
    require('../model/class_db.php');
   ?>